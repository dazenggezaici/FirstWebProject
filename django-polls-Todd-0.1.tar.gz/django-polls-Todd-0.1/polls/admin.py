from django.contrib import admin

from .models import Question, Choice

# admin.site.register(Question)
admin.site.register(Choice)


# class ChoiceInline(admin.StackedInline):
class ChoiceInline(admin.TabularInline):  # 将StackedInline替换成TabularInline（从宽松到紧凑）
    model = Choice  # 模板调用Choice模板
    extra = 3  # 默认三个选项


class QuestionAdmin(admin.ModelAdmin):
    fieldsets = [
        ('在这里填入问题', {'fields': ['question_text']}),
        ('时间的信息', {'fields': ['pub_date']}),
        # ('时间的信息', {'fields': ['pub_date'], 'classes': ['collapse']}),加了后面的classes...之后就会显示一个可以隐藏显示此栏的按钮（默认隐藏）
    ]
    inlines = [ChoiceInline]
    # list_display = ('question_text', 'pub_date')
    list_display = ('question_text', 'pub_date', 'was_published_recently')
    list_filter = ['pub_date']
    search_fields = ['question_text']


admin.site.register(Question, QuestionAdmin)
